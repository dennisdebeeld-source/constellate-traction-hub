import React, { useMemo } from 'react';
import { Lead } from '../types';
import { STAGES } from '../constants';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardHeaderProps {
  leads: Lead[];
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({ leads }) => {
  const metrics = useMemo(() => {
    const total = leads.length;
    const paidPilots = leads.filter(l => l.type === 'Paid Pilot').length;
    const activeLOIs = leads.filter(l => l.type === 'LOI').length;
    
    // Calculate total value (mock calculation for demo aesthetics)
    // Only count Paid Pilots
    const pilotValue = paidPilots * 150000; // Mock value $150k per pilot
    const valueString = `$${(pilotValue / 1000).toFixed(0)}k`;

    // Conversion Rate Logic
    // Numerator: Leads that have reached Commitment Stage (Stage 4) or beyond (Execution, Review).
    // Denominator: Total Leads.
    const leadsConverted = leads.filter(l => l.stage >= 4).length;
    
    const conversionRate = total > 0 
        ? Math.round((leadsConverted / total) * 100) 
        : 0;

    // Show conversion if we have any leads at all
    const showConversion = total > 0;

    return { total, paidPilots, activeLOIs, valueString, conversionRate, showConversion };
  }, [leads]);

  const chartData = useMemo(() => {
    return STAGES.map(stage => {
      const count = leads.filter(l => l.stage === stage.id).length;
      return {
        name: stage.label,
        count: count,
        shortName: `S${stage.id}`
      };
    });
  }, [leads]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10 w-full">
      {/* Metrics Cards */}
      <div className="lg:col-span-1 grid grid-cols-2 gap-4">
        <div className="bg-black border border-zinc-800 p-6 flex flex-col justify-between">
            <span className="text-xs uppercase tracking-widest text-zinc-500">Total Leads</span>
            <div className="mt-2">
                <span className="text-4xl font-light text-white">{metrics.total}</span>
            </div>
        </div>
        <div className="bg-black border border-zinc-800 p-6 flex flex-col justify-between">
            <span className="text-xs uppercase tracking-widest text-zinc-500">Paid Pilots</span>
            <div className="mt-2">
                <span className="text-4xl font-light text-white">{metrics.paidPilots}</span>
                <span className="block text-xs text-zinc-500 mt-1">Est. {metrics.valueString}</span>
            </div>
        </div>
        <div className="col-span-2 bg-black border border-zinc-800 p-6 flex items-center justify-between">
            <div>
                 <span className="text-xs uppercase tracking-widest text-zinc-500">Active LOIs</span>
                 <div className="mt-1 text-3xl font-light text-white">{metrics.activeLOIs}</div>
            </div>
            <div className="h-full w-[1px] bg-zinc-900 mx-4"></div>
            <div className="text-right">
                <span className="text-xs uppercase tracking-widest text-zinc-500">Conversion Rate</span>
                <div className="mt-1 text-xl font-light text-white">
                    {metrics.showConversion ? `${metrics.conversionRate}%` : '--'}
                </div>
            </div>
        </div>
      </div>

      {/* Distribution Chart */}
      <div className="lg:col-span-2 bg-black border border-zinc-800 p-6">
        <div className="mb-4 flex justify-between items-end">
            <h3 className="text-xs uppercase tracking-widest text-zinc-500">Funnel Distribution</h3>
        </div>
        <div className="h-[140px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
            >
              <XAxis type="number" hide />
              <YAxis 
                dataKey="name" 
                type="category" 
                tick={{ fill: '#52525b', fontSize: 10 }} 
                width={110}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                cursor={{ fill: '#18181b', opacity: 0.4 }}
                contentStyle={{ backgroundColor: '#000', border: '1px solid #333', color: '#fff' }}
                itemStyle={{ color: '#fff' }}
              />
              <Bar dataKey="count" barSize={12} radius={[0, 4, 4, 0]}>
                {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="#ffffff" fillOpacity={0.4 + (index * 0.12)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};