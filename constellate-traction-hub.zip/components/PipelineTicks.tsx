import React from 'react';
import { STAGES } from '../constants';

interface PipelineTicksProps {
  currentStage: number;
  onStageClick: (stageId: number) => void;
}

export const PipelineTicks: React.FC<PipelineTicksProps> = ({ currentStage, onStageClick }) => {
  return (
    <div className="flex flex-col w-full max-w-md">
      <div className="relative flex items-center justify-between w-full h-8">
        {/* Connecting Line */}
        <div className="absolute top-1/2 left-0 w-full h-[1px] bg-zinc-800 -z-0" />
        
        {/* Ticks */}
        {STAGES.map((stage) => {
          const isCompleted = stage.id < currentStage;
          const isCurrent = stage.id === currentStage;
          const isFuture = stage.id > currentStage;

          return (
            <button
              key={stage.id}
              onClick={() => onStageClick(stage.id)}
              className="relative z-10 group focus:outline-none"
            >
              <div
                className={`
                  w-3 h-3 rounded-full transition-all duration-300 ease-out
                  ${isCompleted ? 'bg-white border border-white' : ''}
                  ${isCurrent ? 'bg-white border border-white shadow-[0_0_20px_2px_rgba(255,255,255,1)] scale-125' : ''}
                  ${isFuture ? 'bg-black border border-zinc-700 hover:border-zinc-500' : ''}
                `}
              />
            </button>
          );
        })}
      </div>
      <div className="flex justify-between w-full px-1">
         <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-medium">
             {STAGES.find(s => s.id === currentStage)?.label}
         </span>
      </div>
    </div>
  );
};