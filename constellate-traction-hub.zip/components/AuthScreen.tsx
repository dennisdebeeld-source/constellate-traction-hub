import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  GoogleAuthProvider, 
  signInWithPopup,
  sendPasswordResetEmail 
} from 'firebase/auth';
import { auth } from '../firebase';
import { ArrowRight, Lock, KeyRound, ArrowLeft } from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [isResetMode, setIsResetMode] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setLoading(true);

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      // Only log unexpected errors to the console to keep it clean
      const errorCode = err.code;
      const expectedErrors = [
        'auth/invalid-credential',
        'auth/user-not-found',
        'auth/wrong-password',
        'auth/invalid-login-credentials',
        'auth/email-already-in-use',
        'auth/weak-password'
      ];

      if (!expectedErrors.includes(errorCode)) {
        console.error("Auth Error:", errorCode, err.message);
      }
      
      // User-friendly error mapping
      if (errorCode === 'auth/invalid-credential' || errorCode === 'auth/user-not-found' || errorCode === 'auth/wrong-password' || errorCode === 'auth/invalid-login-credentials') {
        setError("Invalid email or password.");
      } else if (errorCode === 'auth/email-already-in-use') {
        setError("User already exists. Please sign in.");
      } else if (errorCode === 'auth/weak-password') {
        setError("Password should be at least 6 characters.");
      } else if (errorCode === 'auth/network-request-failed') {
        setError("Network error. Please check your connection.");
      } else {
        setError(err.message || "An authentication error occurred.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setLoading(true);

    if (!email) {
        setError("Please enter your email address.");
        setLoading(false);
        return;
    }

    try {
        await sendPasswordResetEmail(auth, email);
        setSuccessMessage("Password reset link sent. Check your inbox.");
    } catch (err: any) {
        console.error("Reset Error:", err.code);
        if (err.code === 'auth/user-not-found') {
             setError("No account found with this email.");
        } else if (err.code === 'auth/invalid-email') {
             setError("Invalid email address.");
        } else {
             setError("Failed to send reset email. Try again.");
        }
    } finally {
        setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setSuccessMessage('');
    setLoading(true);
    try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
    } catch (err: any) {
        console.error("Google Auth Error:", err);
        
        if (err.code === 'auth/unauthorized-domain') {
            setError("This domain is not authorized. Add it to Firebase Console -> Auth -> Settings.");
        } else if (err.code === 'auth/popup-closed-by-user') {
            setError("Sign-in cancelled.");
        } else if (err.code === 'auth/popup-blocked') {
            setError("Popup blocked. Please allow popups for this site.");
        } else {
            setError("Google sign-in failed. Please try again.");
        }
    } finally {
        setLoading(false);
    }
  };

  const toggleResetMode = () => {
    setIsResetMode(!isResetMode);
    setError('');
    setSuccessMessage('');
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-white font-sans">
      <div className="w-full max-w-md">
        
        {/* Header */}
        <div className="mb-12 text-center">
            <div className="w-6 h-6 bg-white rotate-45 mx-auto mb-6"></div>
            <h1 className="text-xl tracking-[0.2em] font-light uppercase mb-2">Constellate Proteomics</h1>
            <p className="text-xs text-zinc-500 uppercase tracking-widest">Restricted Access</p>
        </div>

        {/* Auth Box */}
        <div className="border border-zinc-800 bg-black p-8 relative overflow-hidden">
          {/* Decorative glow */}
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-zinc-700 to-transparent opacity-50" />
          
          <h2 className="text-lg font-light mb-6 flex items-center gap-2">
            {isResetMode ? (
                <KeyRound size={16} className="text-zinc-500" />
            ) : (
                <Lock size={16} className="text-zinc-500" />
            )}
            <span>
                {isResetMode 
                    ? 'Reset Credentials' 
                    : (isLogin ? 'Authenticate' : 'Register Identity')}
            </span>
          </h2>

          <form onSubmit={isResetMode ? handleResetPassword : handleSubmit} className="space-y-5">
            <div>
                <label className="block text-[10px] uppercase tracking-wider text-zinc-500 mb-2">Email Address</label>
                <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-zinc-900/50 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors placeholder-zinc-700 text-sm"
                    placeholder="researcher@institute.org"
                />
            </div>

            {!isResetMode && (
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-[10px] uppercase tracking-wider text-zinc-500">Password</label>
                        {isLogin && (
                            <button 
                                type="button" 
                                onClick={toggleResetMode}
                                className="text-[10px] uppercase tracking-wider text-zinc-600 hover:text-zinc-400 transition-colors"
                            >
                                Forgot Password?
                            </button>
                        )}
                    </div>
                    <input 
                        type="password" 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-zinc-900/50 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors placeholder-zinc-700 text-sm"
                        placeholder="••••••••"
                    />
                </div>
            )}

            {error && (
              <div className="text-red-500 text-xs border border-red-900/30 bg-red-950/10 p-3 mt-2 flex items-start gap-2">
                <div className="w-1 h-full bg-red-500 shrink-0"></div>
                {error}
              </div>
            )}
            
            {successMessage && (
              <div className="text-green-500 text-xs border border-green-900/30 bg-green-950/10 p-3 mt-2 flex items-start gap-2">
                <div className="w-1 h-full bg-green-500 shrink-0"></div>
                {successMessage}
              </div>
            )}

            <button 
                type="submit"
                disabled={loading}
                className="w-full bg-white text-black font-medium py-3 hover:bg-zinc-200 transition-colors mt-2 flex items-center justify-center gap-2 disabled:opacity-50"
            >
                {loading ? (
                  <span className="block w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <span>
                        {isResetMode 
                            ? 'Send Reset Link' 
                            : (isLogin ? 'Enter System' : 'Create Account')}
                    </span>
                    {!isResetMode && <ArrowRight size={14} />}
                  </>
                )}
            </button>
          </form>

          {isResetMode ? (
             <div className="mt-6 pt-6 border-t border-zinc-900 text-center">
                 <button 
                     type="button"
                     onClick={toggleResetMode}
                     className="text-xs text-zinc-500 hover:text-white transition-colors uppercase tracking-wider flex items-center justify-center gap-2 mx-auto"
                 >
                     <ArrowLeft size={14} />
                     <span>Back to Login</span>
                 </button>
             </div>
          ) : (
            <>
                <div className="flex items-center my-6">
                    <div className="flex-1 border-t border-zinc-800"></div>
                    <span className="px-3 text-[10px] text-zinc-600 uppercase tracking-widest">Or</span>
                    <div className="flex-1 border-t border-zinc-800"></div>
                </div>

                <button
                    type="button"
                    onClick={handleGoogleLogin}
                    disabled={loading}
                    className="w-full bg-zinc-900 text-white border border-zinc-800 font-medium py-3 hover:bg-zinc-800 transition-colors flex items-center justify-center gap-3 disabled:opacity-50 text-sm"
                >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.26.81-.58z" fill="#FBBC05" />
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                    </svg>
                    <span>Continue with Google</span>
                </button>

                <div className="mt-6 pt-6 border-t border-zinc-900 text-center">
                    <button 
                        type="button"
                        onClick={() => {
                        setIsLogin(!isLogin);
                        setError('');
                        setSuccessMessage('');
                        }}
                        className="text-xs text-zinc-500 hover:text-white transition-colors uppercase tracking-wider"
                    >
                        {isLogin ? "New user? Create Account" : "Existing user? Sign In"}
                    </button>
                </div>
            </>
          )}
        </div>
        
        <div className="mt-8 text-center text-[10px] text-zinc-600 font-mono">
           SECURE CONNECTION // ENCRYPTED
        </div>
      </div>
    </div>
  );
};