import React, { useState, useEffect } from 'react';
import { LeadType, Lead } from '../types';
import { STAGES } from '../constants';
import { X, Trash2 } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface AddLeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (lead: Lead) => Promise<void> | void;
  onDelete: (leadId: string) => Promise<void> | void;
  initialLead?: Lead | null;
}

export const AddLeadModal: React.FC<AddLeadModalProps> = ({ isOpen, onClose, onSave, onDelete, initialLead }) => {
  const [name, setName] = useState('');
  const [type, setType] = useState<LeadType>(null);
  const [stage, setStage] = useState<number>(1);
  const [description, setDescription] = useState('');
  const [statusNote, setStatusNote] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  // Reset or populate form when modal opens or initialLead changes
  useEffect(() => {
    if (isOpen) {
      setError('');
      if (initialLead) {
        setName(initialLead.name);
        setType(initialLead.type);
        setStage(initialLead.stage);
        setDescription(initialLead.description);
        setStatusNote(initialLead.statusNote);
      } else {
        setName('');
        setType(null); // Default to no type
        setStage(1);
        setDescription('');
        setStatusNote('');
      }
    }
  }, [isOpen, initialLead]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validation: Type is mandatory for Commitment stage (4) and above
    // Stages: 4=Commitment, 5=Execution, 6=Review
    if (stage >= 4 && !type) {
        setError("Lead Type (LOI or Paid Pilot) is required for Commitment, Execution, or Review stages.");
        return;
    }

    setIsSaving(true);
    
    const newLead: Lead = {
      id: initialLead ? initialLead.id : uuidv4(),
      name,
      type,
      description,
      stage,
      statusNote,
      isHighIntensity: type === 'Paid Pilot',
    };

    try {
      await onSave(newLead);
      onClose();
    } catch (error) {
      console.error("Failed to save:", error);
      setError("Failed to save lead. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!initialLead) return;
    
    if (window.confirm("Are you sure you want to delete this lead? This action cannot be undone.")) {
        setIsSaving(true);
        try {
            await onDelete(initialLead.id);
            // Modal closing is handled by parent upon successful deletion usually, 
            // but we ensure it here implicitly if onDelete resolves.
        } catch (error) {
            console.error("Failed to delete:", error);
            setError("Failed to delete lead.");
            setIsSaving(false);
        }
    }
  };

  const toggleType = (selectedType: 'LOI' | 'Paid Pilot') => {
      if (type === selectedType) {
          setType(null); // Deselect
      } else {
          setType(selectedType);
      }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-black border border-zinc-800 shadow-2xl p-8 relative">
        <button 
            type="button"
            onClick={onClose}
            disabled={isSaving}
            className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors disabled:opacity-50"
        >
            <X size={20} />
        </button>
        
        <h2 className="text-xl font-light text-white mb-6 uppercase tracking-widest">
          {initialLead ? 'Edit Lead Entry' : 'New Lead Entry'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
            <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-2">Lead Name</label>
                <input 
                    type="text" 
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={isSaving}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors placeholder-zinc-700 disabled:opacity-50"
                    placeholder="e.g. Acme Genomics"
                />
            </div>

            <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-2">Pipeline Stage</label>
                <select 
                    value={stage}
                    onChange={(e) => setStage(Number(e.target.value))}
                    disabled={isSaving}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors disabled:opacity-50"
                >
                    {STAGES.map((s) => (
                        <option key={s.id} value={s.id}>
                            {s.id}. {s.label}
                        </option>
                    ))}
                </select>
            </div>

            <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-2">
                    Type <span className="text-zinc-600 lowercase font-normal">(required for Stage 4+)</span>
                </label>
                <div className="flex gap-4">
                    <button
                        type="button"
                        onClick={() => toggleType('LOI')}
                        disabled={isSaving}
                        className={`flex-1 py-2 text-sm border transition-colors ${type === 'LOI' ? 'bg-zinc-800 border-zinc-600 text-white' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600'} disabled:opacity-50`}
                    >
                        LOI
                    </button>
                    <button
                        type="button"
                        onClick={() => toggleType('Paid Pilot')}
                        disabled={isSaving}
                        className={`flex-1 py-2 text-sm border transition-colors ${type === 'Paid Pilot' ? 'bg-white border-white text-black' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600'} disabled:opacity-50`}
                    >
                        Paid Pilot
                    </button>
                </div>
            </div>

            <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-2">Description</label>
                <textarea 
                    rows={2}
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    disabled={isSaving}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors placeholder-zinc-700 disabled:opacity-50"
                    placeholder="Project scope..."
                />
            </div>

            <div>
                <label className="block text-xs uppercase tracking-wider text-zinc-500 mb-2">Status Note</label>
                <input 
                    type="text" 
                    required
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    disabled={isSaving}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white p-3 focus:outline-none focus:border-white transition-colors placeholder-zinc-700 disabled:opacity-50"
                    placeholder="Latest update..."
                />
            </div>

            {error && (
                <div className="p-3 bg-red-900/20 border border-red-900/50 text-red-500 text-xs">
                    {error}
                </div>
            )}

            <div className="flex gap-3 mt-4">
                {initialLead && (
                    <button
                        type="button"
                        onClick={handleDelete}
                        disabled={isSaving}
                        className="px-4 border border-red-900 text-red-700 hover:bg-red-900/20 hover:text-red-500 transition-colors disabled:opacity-50 flex items-center justify-center"
                        title="Delete Lead"
                    >
                        <Trash2 size={20} />
                    </button>
                )}
                <button 
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 bg-white text-black font-medium py-3 hover:bg-zinc-200 transition-colors flex justify-center items-center disabled:opacity-50"
                >
                    {isSaving ? (
                    <span className="w-5 h-5 border-2 border-zinc-800 border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                    initialLead ? 'Update Lead' : 'Initialize Lead'
                    )}
                </button>
            </div>
        </form>
      </div>
    </div>
  );
};