import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, // Add this
  onSnapshot, 
  query 
} from 'firebase/firestore';
import { db } from '../firebase';
import { Lead } from '../types';

const LEADS_COLLECTION = 'leads';

// Subscribe to real-time updates
export const subscribeToLeads = (onLeadsUpdate: (leads: Lead[]) => void) => {
  const q = query(collection(db, LEADS_COLLECTION));
  
  // Returns the unsubscribe function
  return onSnapshot(q, (snapshot) => {
    const leads = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id
    })) as Lead[];
    onLeadsUpdate(leads);
  }, (error) => {
    console.error("Error fetching leads:", error);
  });
};

// Create or Update a lead (using setDoc with merge to handle both)
export const saveLeadToFirestore = async (lead: Lead) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, lead.id);
    // Convert to plain object if needed, but Firestore SDK handles objects well.
    // Ensure no undefined values if using strict types, but Lead type looks safe.
    await setDoc(leadRef, lead, { merge: true });
  } catch (error) {
    console.error("Error saving lead:", error);
    throw error;
  }
};

// Specific update for stage dragging/clicking
export const updateLeadStageInFirestore = async (leadId: string, newStage: number) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    await updateDoc(leadRef, { stage: newStage });
  } catch (error) {
    console.error("Error updating lead stage:", error);
    throw error;
  }
};

// Delete a lead
export const deleteLeadFromFirestore = async (leadId: string) => {
  try {
    const leadRef = doc(db, LEADS_COLLECTION, leadId);
    await deleteDoc(leadRef);
  } catch (error) {
    console.error("Error deleting lead:", error);
    throw error;
  }
};